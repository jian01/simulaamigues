TP1 - Simulación

Extraer todo en la misma carpeta y abrir el html